close all;

k=k(1);

if k==0
    save testfile1 k e de;
elseif k==10
    save testfile2 k e de;
elseif k==20
    save testfile3 k e de;
elseif k==30
    save testfile4 k e de;
end    