function [sys,x0,str,ts]=s_function(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 4;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 0;
sys=simsizes(sizes);
x0=[1;0;pi;0];
str=[];
ts=[];
function sys=mdlDerivatives(t,x,u)
z1=x(1);
theta1=x(3);
theta2=x(4);

epc=0.1;
v=u(1);

den=1-epc^2*(cos(theta1))^2;
dz2=(-z1+epc*theta2^2*sin(theta1)-epc*cos(theta1)*v)/den;
dth2=(epc*cos(theta1)*(z1-epc*theta2^2*sin(theta1))+v)/den;

sys(1)=x(2);
sys(2)=dz2;
sys(3)=x(4);
sys(4)=dth2;
function sys=mdlOutputs(t,x,u)
sys(1)=x(1);
sys(2)=x(2);
sys(3)=x(3);
sys(4)=x(4);