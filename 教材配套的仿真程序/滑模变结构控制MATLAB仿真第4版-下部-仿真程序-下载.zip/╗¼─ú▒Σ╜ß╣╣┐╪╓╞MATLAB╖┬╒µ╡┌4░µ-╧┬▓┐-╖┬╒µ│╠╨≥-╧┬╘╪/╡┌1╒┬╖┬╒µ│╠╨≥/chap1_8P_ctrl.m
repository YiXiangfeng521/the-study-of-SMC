function [sys,x0,str,ts] = spacemodel(t,x,u,flag) 
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;  
sizes.NumOutputs     = 2;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  =[];
str = [];
ts  = [0 0];
function sys=mdlOutputs(t,x,u)
persistent k p_1

xd=u(1);
yd=u(2);
xd=cos(t);dxd=-sin(t);
yd=sin(t);dyd=cos(t);

x1=u(3);
y1=u(4);

k1=0.30;k2=0.30;
xe=x1-xd;
s1=xe;
u1=dxd-k1*s1;

ye=y1-yd;
s2=ye;
u2=dyd-k2*s2;

%To guarantee p is in [0,2*pi], instead of thd=atan(u2/u1);
z=u1+u2*i;
p=angle(z);  %[-pi,pi]
if t==0
    k=0;
    p_1=p;
end
if p*p_1<-0.8*pi^2  %Change nearly in -pi and +pi
   k=k+1;
end
p_1=p;
thd=p+2*pi*k;

v=u1/cos(thd);

sys(1)=v;
sys(2)=thd;