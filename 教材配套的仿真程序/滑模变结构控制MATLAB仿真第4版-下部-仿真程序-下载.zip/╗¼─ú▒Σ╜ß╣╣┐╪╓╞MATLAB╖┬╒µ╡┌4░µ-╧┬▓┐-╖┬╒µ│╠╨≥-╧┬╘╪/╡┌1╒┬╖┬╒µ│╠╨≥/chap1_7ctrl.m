function [sys,x0,str,ts] = s_function(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];
function sys=mdlOutputs(t,x,u)
epc=0.1;
z1=u(1);
z2=u(2);
theta1=u(3);
theta2=u(4);

x1=z1+epc*sin(theta1);
x2=z2+epc*theta2*cos(theta1);
x3=theta1;
x4=theta2;

f1=-x1+epc*sin(x3)+11*epc*x3;
f1_x1=-1;
f1_x3=epc*(cos(x3)+11);

dt_f1_x1=0;
dt_f1_x3=-epc*sin(x3)*x4;

e1=x1;
e2=x2;
e3=f1;
e4=f1_x1*x2+f1_x3*x4;

a=3.0;
c1=a^3;c2=3*a^2;c3=3*a;
s=c1*e1+c2*e2+c3*e3+e4;

M=c1*x2+c2*(f1-11*epc*x3)+c3*e4+f1_x1*(f1-11*epc*x3)+dt_f1_x3*x4;

k=5;xite=0.5;

fai=0.10;
if abs(s)<=fai
   sat=s/fai;
else
   sat=sign(s);
end

ut=1/f1_x3*(-M-k*s-xite*sat);
v=(1-epc^2*(cos(theta1))^2)*ut-epc*cos(theta1)*(z1-epc*theta2^2*sin(theta1));

sys(1)=v;