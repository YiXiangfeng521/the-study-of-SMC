function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];
function sys=mdlOutputs(t,x,u)
x1=u(1);x2=u(2);x3=u(3);x4=u(4);
l=10;g=9.8;

f1=g*sin(x1)/l+x3^3+x3;
f1_x1=g*cos(x1)/l;
f1_x3=3*x3^2+1;

dt_f1_x1=-g*sin(x1)/l*x2;
dt_f1_x3=6*x3*x4;

e1=x1;
e2=x2;
e3=f1;
e4=f1_x1*x2+f1_x3*x4;

a=50;
c1=a^3;c2=3*a^2;c3=3*a;
s=c1*e1+c2*e2+c3*e3+e4;

M=c1*x2+c2*(f1-x3)+c3*(f1_x1*x2+f1_x3*x4)+dt_f1_x1*x2+f1_x1*(f1-x3)+dt_f1_x3*x4;

k=1;xite=5;

fai=0.010;
if abs(s)<=fai
   sat=s/fai;
else
   sat=sign(s);
end

ut=1/f1_x3*(-M-k*s-xite*sat);
sys(1)=ut;