function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];
function sys=mdlOutputs(t,x,u)
l=10;g=9.8;

x1=u(1);x2=u(2);x3=u(3);x4=u(4);

c3=9;
c2=g/l+27;
c1=c3*g/l+27;
s=c1*x1+c2*x2+c3*x3+x4;

D=3.0;
xite=D+0.10;

S=2;
if S==1
    sat=sign(s);
elseif S==2         %Saturated function 
   fai=0.10;
   if abs(s)<=fai
      sat=s/fai;
   else
      sat=sign(s);
   end
end

k=10;
ut=-c1*x2-c2*(g/l*sin(x1)+x3)-c3*x4-k*s-xite*sat;
sys(1)=ut;