close all;

figure(1);
subplot(211);
plot(t,x(:,1),'r','linewidth',2);
xlabel('time(s)');ylabel('z1');
subplot(212);
plot(t,x(:,2),'r','linewidth',2);
xlabel('time(s)');ylabel('dz1');

figure(2);
subplot(211);
plot(t,x(:,3),'r','linewidth',2);
xlabel('time(s)');ylabel('th1');
subplot(212);
plot(t,x(:,4),'r','linewidth',2);
xlabel('time(s)');ylabel('dth1');

figure(3);
plot(t,ut(:,1),'r','linewidth',2);
xlabel('time(s)');ylabel('v');