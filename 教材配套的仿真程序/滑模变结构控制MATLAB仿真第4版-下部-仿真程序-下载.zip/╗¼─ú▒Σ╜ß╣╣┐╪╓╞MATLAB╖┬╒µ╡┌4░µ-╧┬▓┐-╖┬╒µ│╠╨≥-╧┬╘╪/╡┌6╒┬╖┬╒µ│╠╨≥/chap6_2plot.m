close all;

figure(1);
subplot(211);
plot(t,x1(:,1),'k',t,x1(:,2),'k:','linewidth',2);
xlabel('time(s)');ylabel('position tracking for link 1');
legend('Ideal position signal','tracking signal');
subplot(212);
plot(t,x2(:,1),'k',t,x2(:,2),'k:','linewidth',2);
xlabel('time(s)');ylabel('position tracking for link 2');
legend('Ideal position signal','tracking signal');

figure(2);
subplot(211);
plot(t,x3(:,1),'k',t,x3(:,2),'k:','linewidth',2);
xlabel('time(s)');ylabel('speed tracking for link 1');
legend('Ideal speed signal','tracking signal');
subplot(212);
plot(t,x4(:,1),'k',t,x4(:,2),'k:','linewidth',2);
xlabel('time(s)');ylabel('speed tracking for link 2');
legend('Ideal speed signal','tracking signal');

figure(3);
subplot(211);
plot(t,tol1(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('control input of link 1');
  
subplot(212);
plot(t,tol2(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('control input of link 2');