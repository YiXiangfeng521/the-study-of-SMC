close all;

figure(1);
subplot(311);
plot(t,y(:,1),'k',t,y(:,4),'k:','linewidth',2);
xlabel('time(s)');ylabel('gama');
legend('ideal angle of rolling','angle of rolling tracking');

subplot(312);
plot(t,y(:,2),'k',t,y(:,5),'k:','linewidth',2);
xlabel('time(s)');ylabel('Fai');
legend('ideal angle of yawing','angle of yawing tracking');

subplot(313);
plot(t,y(:,3),'k',t,y(:,6),'k:','linewidth',2);
xlabel('time(s)');ylabel('fai');
legend('ideal angle of  pitching','angle of pitching tracking');

figure(2);
subplot(311);
plot(t,wc(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('wc of rolling');
subplot(312);
plot(t,wc(:,2),'k','linewidth',2);
xlabel('time(s)');ylabel('wc of yawing');
subplot(313);
plot(t,wc(:,3),'k','linewidth',2);
xlabel('time(s)');ylabel('wc of pitching');

figure(3);
subplot(311);
plot(t,M(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('Control input,rolling');
subplot(312);
plot(t,M(:,2),'k','linewidth',2);
xlabel('time(s)');ylabel('Control input,yawing');
subplot(313);
plot(t,M(:,3),'k','linewidth',2);
xlabel('time(s)');ylabel('Control input,pitching');