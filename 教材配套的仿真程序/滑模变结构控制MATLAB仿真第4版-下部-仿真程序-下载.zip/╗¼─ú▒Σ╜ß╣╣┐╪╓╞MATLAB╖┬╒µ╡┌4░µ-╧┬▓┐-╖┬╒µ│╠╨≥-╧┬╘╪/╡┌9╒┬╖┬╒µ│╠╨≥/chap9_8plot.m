close all;
figure(1)
plot3(1/2*cos(t/2),1/2*sin(t/2),2+t/10,'k','linewidth',2);
hold on;
plot3(x(:,1),x(:,2),x(:,3),'r-.','linewidth',2);
legend('ideal trajectory','position tracking');
xlabel('x');ylabel('y');zlabel('z');

Pd=[0.5*cos(t/2) 0.5*sin(t/2) 2+t/10];
figure(2);
subplot(311);
plot(t,x(:,1)-Pd(:,1),'b','linewidth',2);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
xlabel('Time(s)');ylabel('e_x');
subplot(312);
plot(t,x(:,2)-Pd(:,2),'b','linewidth',2);
xlabel('Time(s)');ylabel('e_y');
subplot(313);
plot(t,x(:,3)-Pd(:,3),'b','linewidth',2);
xlabel('Time(s)');ylabel('e_z');

figure(3);
subplot(311);
plot(t,Angle(:,2),'r','linewidth',2);
hold on;
plot(t,x(:,7),'b--','linewidth',2);
xlabel('Time(s)');ylabel('\phi');
legend('ideal \phi_d','practical \phi');
subplot(312);
plot(t,Angle(:,1),'r','linewidth',2);
xlabel('Time(s)');ylabel('\theta');
hold on;
plot(t,x(:,8),'b--','linewidth',2);
legend('ideal \theta_d','practical \theta');

subplot(313);
plot(t,pi/3*t./t,'r','linewidth',2);
hold on;
plot(t,x(:,9),'b--','linewidth',2);
xlabel('Time(s)');ylabel('\psi');
legend('ideal \psi_d','practical \psi');

figure(4);
subplot(221);
plot(t,ut(:,1),'b','linewidth',2);
xlabel('Time(s)');ylabel('Lift force U_1');
subplot(222);
plot(t,ut(:,2),'b','linewidth',2);
xlabel('Time(s)');ylabel('Torque \Gamma_1');
subplot(223);
plot(t,ut(:,3),'b','linewidth',2);
xlabel('Time(s)');ylabel('Torque \Gamma_2');
subplot(224);
plot(t,ut(:,4),'b','linewidth',2);
xlabel('Time(s)');ylabel('Torque \Gamma_3');

figure(5)
plot(t,mp(:,1),'b','linewidth',2);
hold on 
plot(t,m(:,1),'r--','linewidth',2);
xlabel('Time(s)');ylabel('m');
legend('m estimation','m true value');

figure(6);
subplot(311);
plot(t,0.1*sin(0.1*pi*t),'r',t,dF(:,1),'b-','linewidth',2);
legend('d_x','d_x estimation');
subplot(312);
plot(t,0.1*cos(0.1*pi*t),'r',t,dF(:,2),'b-.','linewidth',2);
legend('d_y','d_y estimation');
ylabel('estimation of d_F ');
subplot(313);
plot(t,0.1*cos(0.1*pi*t),'r',t,dF(:,3),'b--','linewidth',2);
legend('d_z','d_z estimation');
xlabel('Time(s)');