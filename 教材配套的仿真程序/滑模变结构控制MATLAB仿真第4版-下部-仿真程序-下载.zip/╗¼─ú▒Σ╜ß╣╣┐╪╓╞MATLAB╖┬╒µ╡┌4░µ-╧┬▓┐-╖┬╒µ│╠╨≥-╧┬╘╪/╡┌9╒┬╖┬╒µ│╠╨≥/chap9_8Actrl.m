function [sys,x0,str,ts] = spacemodel(t,x,u,flag) 
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 3;
sizes.NumInputs      = 18;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];
function sys=mdlOutputs(t,x,u)
Ixx=0.004;Iyy=0.004;Izz=0.008;
psid=pi/3;

THETAd=[u(4),u(1),psid]';
DTHETAd=[u(5),u(2),0]';
DDTHETAd=[u(6),u(3),0]'; 
THETA=[u(13),u(14),u(15)]';
DTHETA=[u(16),u(17),u(18)]';

phi=THETA(1);
theta=THETA(2);
psi=THETA(3);
dphi=DTHETA(1);
dtheta=DTHETA(2);
dpsi=DTHETA(3);

e=THETA-THETAd;
de=DTHETA-DTHETAd;

J0=[Ixx 0 0;0 Iyy+Izz 0;0 0 Ixx+Iyy+Izz];

lamda2=diag([50,50,50]);
DTHETAr=DTHETAd-lamda2*e;
sigma=DTHETA-DTHETAr;
DDTHETAr=DDTHETAd-lamda2*de;

c11=0;
c12=-Ixx*dpsi*cos(theta)+(Iyy-Izz)*(dtheta*sin(phi)*cos(phi)+dpsi*sin(phi)^2*cos(theta)-dpsi*cos(phi)^2*cos(theta));
c13=(Izz-Iyy)*dpsi*sin(phi)*cos(phi)*cos(theta)^2;
c21=-c12;
c22=(Izz-Iyy)*dphi*sin(phi)*cos(phi);
c23=-Ixx*dpsi*sin(theta)*cos(theta)+Iyy*dpsi*sin(phi)^2*sin(theta)*cos(theta)+Izz*dpsi*cos(phi)^2*sin(theta)*cos(theta);
c31=-Ixx*dtheta*cos(theta)+(Iyy-Izz)*dpsi*cos(theta)^2*sin(phi)*cos(phi);
c32=(Izz-Iyy)*(dtheta*sin(phi)*cos(phi)*sin(theta)+dphi*sin(phi)^2*cos(theta)-dphi*cos(phi)^2*cos(theta))+Ixx*dpsi*sin(theta)*cos(theta)-Iyy*dpsi*sin(phi)^2*sin(theta)*cos(theta)-Izz*dpsi*cos(phi)^2*sin(theta)*cos(theta);
c33=Ixx*dtheta*sin(theta)*cos(theta)+Iyy*(dphi*cos(phi)*sin(phi)*cos(theta)^2-dtheta*sin(phi)^2*cos(theta)*sin(theta))-Izz*(dphi*cos(phi)*sin(phi)*cos(theta)^2+dtheta*cos(phi)^2*cos(theta)*sin(theta));
C=[c11 c12 c13;c21 c22 c23;c31 c32 c33];
C0=0.90*C;

fai=0.20;   
if norm(sigma)<=fai
   sat=1/fai*sigma;
else
   sat=sign(sigma);
end

c2=10;xite2=0.5;
Tol=J0*DDTHETAr+C0*DTHETA-c2*sigma-xite2*sat;
for i =1:3
    sys(i)=Tol(i);
end