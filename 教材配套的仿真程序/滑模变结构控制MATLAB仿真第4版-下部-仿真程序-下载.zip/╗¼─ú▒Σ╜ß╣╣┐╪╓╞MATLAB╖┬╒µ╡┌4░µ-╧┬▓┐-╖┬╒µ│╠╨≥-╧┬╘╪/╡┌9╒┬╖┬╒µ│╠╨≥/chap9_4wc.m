function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumOutputs     = 3;
sizes.NumInputs      = 12;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [];
function sys=mdlOutputs(t,x,u)
sw=[u(1) u(2) u(3)]';

gama=u(4);
Fai=u(5);
R=[1 tan(Fai)*sin(gama) tan(Fai)*cos(gama);
   0 cos(gama)           -sin(gama);
   0 sin(gama)/cos(Fai) cos(gama)/cos(Fai)];
the=[u(7) u(8) u(9)]';
dthc=[u(10) u(11) u(12)]';

K1=10*eye(3);
rou1=1.5;
wc=inv(R)*(dthc+K1*the+rou1*sw);
sys(1)=wc(1);
sys(2)=wc(2);
sys(3)=wc(3);