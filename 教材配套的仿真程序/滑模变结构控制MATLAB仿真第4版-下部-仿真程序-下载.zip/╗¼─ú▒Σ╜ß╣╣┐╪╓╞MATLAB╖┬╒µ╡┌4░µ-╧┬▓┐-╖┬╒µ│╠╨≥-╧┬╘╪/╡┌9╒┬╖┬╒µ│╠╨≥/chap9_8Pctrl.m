function [sys,x0,str,ts] = spacemodel(t,x,u,flag) 
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 4;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 7;
sizes.NumInputs      = 12;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  =[0,0,0,2];
str = [];
ts  = [0 0];
function sys=mdlDerivatives(t,x,u)
g=9.8;
P=[u(1),u(2),u(3)]';
dP=[u(4),u(5),u(6)]';
Pd=[1/2*cos(t/2),1/2*sin(t/2),2+t/10]';
psid=pi/3;
dPd=[-1/4*sin(t/2),1/4*cos(t/2),1/10]';
ddPd=[-1/8*cos(t/2),-1/8*sin(t/2),0]';

ep=P-Pd;
dep=dP-dPd;

lambda1=diag([3,3,3]);
sigma1=dep+lambda1*ep;
gamma1=0.6;
dz=sigma1*gamma1;

c1=4;
dp=[x(1),x(2),x(3)]';
U_hat=[0 0 g]'+ddPd-lambda1*dep-c1*sigma1;

gamma2=0.2;
dm=-gamma2*sigma1'*U_hat;
if x(4)>=12&&dm>0
   dmp=0;
else if x(4)<=-12&&dm<0
   dmp=0;
    else
   dmp=dm;
    end       
end
sys(1)=dz(1);
sys(2)=dz(2);
sys(3)=dz(3);
sys(4)=dmp;   %m adaptive law
function sys=mdlOutputs(t,x,u)
g=9.8;
P=[u(1),u(2),u(3)]';
dP=[u(4),u(5),u(6)]';

Pd=[0.5*cos(t/2),0.5*sin(t/2),2+t/10]';
psid=pi/3;
dPd=[-1/4*sin(t/2),1/4*cos(t/2),1/10]';
ddPd=[-1/8*cos(t/2),-1/8*sin(t/2),0]';

ep=P-Pd;
dep=dP-dPd;

lambda1=diag([3,3,3]);
sigma1=dep+lambda1*ep;

c1=4;
dp=[x(1),x(2),x(3)]';
U_hat=[0 0 g]'+ddPd-lambda1*dep-c1*sigma1;

mp=x(4);
U=mp*U_hat-dp;

thetad=atan((U(1)*cos(psid)+U(2)*sin(psid))/U(3));
phid=atan(cos(thetad)*(U(1)*sin(psid)-U(2)*cos(psid))/U(3));
U1=U(3)/(cos(phid)*cos(thetad));
sys(1)=U1; 
sys(2)=thetad;
sys(3)=phid;
sys(4)=x(1);  %dF1 estimation
sys(5)=x(2);  %dF2 estimation
sys(6)=x(3);  %dF3 estimation
sys(7)=x(4);  %m estimation