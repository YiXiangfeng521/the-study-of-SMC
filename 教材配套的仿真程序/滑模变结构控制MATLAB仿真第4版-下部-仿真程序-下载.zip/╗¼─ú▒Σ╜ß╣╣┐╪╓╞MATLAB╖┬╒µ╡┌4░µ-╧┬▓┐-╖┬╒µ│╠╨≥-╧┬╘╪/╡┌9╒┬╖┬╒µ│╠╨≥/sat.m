function S=sat(s) %���ͺ���
fai=0.020;
    if abs(s)<=fai
        S=s/fai;
    else
        S=sign(s);
    end
end