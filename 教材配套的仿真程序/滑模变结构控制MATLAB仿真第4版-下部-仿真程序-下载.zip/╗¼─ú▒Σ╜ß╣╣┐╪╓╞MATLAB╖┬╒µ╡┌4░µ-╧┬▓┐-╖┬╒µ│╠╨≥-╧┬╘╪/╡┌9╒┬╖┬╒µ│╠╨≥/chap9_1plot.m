close all;
figure(1);
subplot(211);
plot(t,y(:,1),'k',t,y(:,3),'k:','linewidth',2);
xlabel('time(sec)');ylabel('Flight hight tracking');
legend('ideal hight','hight tracking');
subplot(212);
plot(t,y(:,2),'k',t,y(:,6),'k:','linewidth',2);
xlabel('time(sec)');ylabel('Pitching angle tracking');
legend('ideal pitching angle','pitching angle tracking');

figure(2);
subplot(211);
plot(t,ut(:,1),'k','linewidth',2);
xlabel('time(sec)');ylabel('Control input 1');
subplot(212);
plot(t,ut(:,2),'k','linewidth',2);
xlabel('time(sec)');ylabel('Control input 2');