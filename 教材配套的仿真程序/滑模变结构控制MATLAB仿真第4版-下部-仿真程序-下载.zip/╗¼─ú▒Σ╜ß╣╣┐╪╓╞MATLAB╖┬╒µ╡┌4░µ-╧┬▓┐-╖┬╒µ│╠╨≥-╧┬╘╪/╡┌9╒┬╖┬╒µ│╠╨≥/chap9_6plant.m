function [sys,x0,str,ts]=chap14_5plant(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 12;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 12;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[2 0 1 0 0 0 0 0 0 0 0 0];
str=[];
ts=[-1 0];
function sys=mdlDerivatives(t,x,u)
u1=u(1);u4=u(2);u2=u(3);u3=u(4);

chap9_6int;

x1=x(1);dx1=x(2);
y=x(3);dy=x(4);
z=x(5);dz=x(6);
theta=x(7);dtheta=x(8);
psi=x(9);dpsi=x(10);
phi=x(11);dphi=x(12);

%���������ض���΢�ַ��̵�����
ddx=u1*(cos(phi)*sin(theta)*cos(psi)+sin(phi)*sin(psi))-K1*dx1/m;
ddy=u1*(sin(phi)*sin(theta)*cos(psi)-cos(phi)*sin(psi))-K2*dy/m;
ddz=u1*(cos(phi)*cos(psi))-g-K3*dz/m;
ddtheta=u2-l*K4*dtheta/I1;
ddpsi=u3-l*K5*dpsi/I2;
ddphi=u4-K6*dphi/I3;

sys(1)=x(2);
sys(2)=ddx;
sys(3)=x(4);
sys(4)=ddy;
sys(5)=x(6);
sys(6)=ddz;
sys(7)=x(8);
sys(8)=ddtheta;
sys(9)=x(10);
sys(10)=ddpsi;
sys(11)=x(12);
sys(12)=ddphi;
function sys=mdlOutputs(t,x,u)
x1=x(1);dx1=x(2);
y=x(3);dy=x(4);
z=x(5);dz=x(6);
theta=x(7);dtheta=x(8);
psi=x(9);dpsi=x(10);
phi=x(11);dphi=x(12);

sys(1)=x1;
sys(2)=dx1;
sys(3)=y;
sys(4)=dy;
sys(5)=z;
sys(6)=dz;
sys(7)=theta;
sys(8)=dtheta;
sys(9)=psi;
sys(10)=dpsi;
sys(11)=phi;
sys(12)=dphi;