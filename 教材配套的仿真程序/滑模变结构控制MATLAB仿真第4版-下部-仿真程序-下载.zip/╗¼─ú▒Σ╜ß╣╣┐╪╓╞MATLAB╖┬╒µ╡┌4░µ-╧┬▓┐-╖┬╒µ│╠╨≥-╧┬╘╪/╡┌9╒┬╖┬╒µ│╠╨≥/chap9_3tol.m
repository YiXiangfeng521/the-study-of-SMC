function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 3;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [];
function sys=mdlOutputs(t,x,u)
J=10;
sn=u(1);
we=u(2);
dwc=u(3);

delta=0.02;
if sn>delta
    sat_sn=1;
    elseif sn<-delta
    sat_sn=-1;
    else sat_sn=sn/delta;  
end
K2=10;
rou2=5;
k=10;
tol=J*(dwc+K2*we)+rou2*sat_sn+k*sn;
sys(1)=tol;