function [sys,x0,str,ts]=s_function(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {1, 2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 6;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[0 0];
function sys=mdlOutputs(t,x,u)
g=9.8;epc=0.50;

x1=u(1);x2=u(2);
y1=u(3);y2=u(4);
th=u(5);dth=u(6);

z1=x1-epc*sin(th);
z2=x2-epc*cos(th)*dth;
dz1=z2;

z1d=t;dz1d=1;ddz1d=0;
z1e=z1-z1d;
dz1e=dz1-dz1d;

w1=y1+epc*(cos(th)-1);
w2=y2-epc*sin(th)*dth;
dw1=w2;

w1d=sin(t);dw1d=cos(t);ddw1d=-sin(t);
w1e=w1-w1d;
dw1e=dw1-dw1d;

c1=3;c2=3;
k1=5;k2=5;
s1=c1*z1e+dz1e;
s2=c2*w1e+dw1e;

v1=-c1*(dz1-dz1d)-k1*s1+ddz1d;
v2=-c2*(dw1-dw1d)+g-k2*s2+ddw1d;

u1b=sqrt(v1^2+v2^2);
u1=u1b+epc*dth^2;
thd=atan(-v1/v2);

sys(1)=u1;
sys(2)=thd;