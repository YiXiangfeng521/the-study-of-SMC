function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 3;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 0;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [];
function sys=mdlOutputs(t,x,u)
sw=u(1);
th=u(2);
dth=u(3);

thc=sin(t);
dthc=cos(t);
ddthc=-sin(t);

the=thc-th;
dthe=dthc-dth;

K1=10.10;
rou1=5;
wc=dthc+K1*the+rou1*sw;
dsw=dthc-wc+K1*the;
dwc=ddthc+K1*dthe+rou1*dsw;

sys(1)=wc;
sys(2)=dwc;