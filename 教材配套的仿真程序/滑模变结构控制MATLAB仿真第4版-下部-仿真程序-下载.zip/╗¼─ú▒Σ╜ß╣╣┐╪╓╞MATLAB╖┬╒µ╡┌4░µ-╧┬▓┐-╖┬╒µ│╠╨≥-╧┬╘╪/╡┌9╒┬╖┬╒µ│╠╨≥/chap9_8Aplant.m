function [sys,x0,str,ts] = spacemodel(t,x,u,flag) 
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 6;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 6;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [0,0,0,0,0,0];
str = [];
ts  = [0 0];
function sys=mdlDerivatives(t,x,u)
Ixx=0.004;Iyy=0.004;Izz=0.008;
Tol=[u(2),u(3),u(4)]';

phi=x(1);dphi=x(2);
theta=x(3);dtheta=x(4);
psi=x(5);dpsi=x(6);

J=[Ixx  0         -Ixx*sin(theta);
   0 Iyy*cos(phi)^2+Izz*sin(phi)^2 (Iyy-Izz)*sin(phi)*cos(phi)*cos(theta);
   -Ixx*sin(theta) (Iyy-Izz)*sin(phi)*cos(phi)*cos(theta) Ixx*sin(theta)^2+Iyy*sin(phi)^2*cos(theta)^2+Izz*cos(phi)^2*cos(theta)^2];

c11=0;
c12=-Ixx*dpsi*cos(theta)+(Iyy-Izz)*(dtheta*sin(phi)*cos(phi)+dpsi*sin(phi)^2*cos(theta)-dpsi*cos(phi)^2*cos(theta));
c13=(Izz-Iyy)*dpsi*sin(phi)*cos(phi)*cos(theta)^2;
c21=-c12;
c22=(Izz-Iyy)*dphi*sin(phi)*cos(phi);
c23=-Ixx*dpsi*sin(theta)*cos(theta)+Iyy*dpsi*sin(phi)^2*sin(theta)*cos(theta)+Izz*dpsi*cos(phi)^2*sin(theta)*cos(theta);
c31=-Ixx*dtheta*cos(theta)+(Iyy-Izz)*dpsi*cos(theta)^2*sin(phi)*cos(phi);
c32=(Izz-Iyy)*(dtheta*sin(phi)*cos(phi)*sin(theta)+dphi*sin(phi)^2*cos(theta)-dphi*cos(phi)^2*cos(theta))+Ixx*dpsi*sin(theta)*cos(theta)-Iyy*dpsi*sin(phi)^2*sin(theta)*cos(theta)-Izz*dpsi*cos(phi)^2*sin(theta)*cos(theta);
c33=Ixx*dtheta*sin(theta)*cos(theta)+Iyy*(dphi*cos(phi)*sin(phi)*cos(theta)^2-dtheta*sin(phi)^2*cos(theta)*sin(theta))-Izz*(dphi*cos(phi)*sin(phi)*cos(theta)^2+dtheta*cos(phi)^2*cos(theta)*sin(theta));
C=[c11 c12 c13;c21 c22 c23;c31 c32 c33];

dTHETA=[dphi dtheta dpsi]';

D1=0.3*sin(0.1*pi*t)+0.1;
D2=0.4*cos(0.1*pi*t)+0.1;
D3=0.5*sin(0.1*pi*t)+0.2;
D=[D1 D2 D3]';

ddA=inv(J)*(Tol-C*dTHETA+D);

sys(1)=x(2);
sys(2)=ddA(1);    %ddphi
sys(3)=x(4);
sys(4)=ddA(2);    %ddtheta
sys(5)=x(6);
sys(6)=ddA(3);    %ddpsi
function sys=mdlOutputs(t,x,u)
sys(1)=x(1); 
sys(2)=x(3);
sys(3)=x(5);
sys(4)=x(2);
sys(5)=x(4);
sys(6)=x(6);