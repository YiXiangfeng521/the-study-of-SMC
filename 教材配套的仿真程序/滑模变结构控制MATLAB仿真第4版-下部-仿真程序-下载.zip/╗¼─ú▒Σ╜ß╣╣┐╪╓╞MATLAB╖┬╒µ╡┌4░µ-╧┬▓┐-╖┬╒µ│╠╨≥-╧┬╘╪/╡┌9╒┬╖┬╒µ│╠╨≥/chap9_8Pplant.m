function [sys,x0,str,ts] = spacemodel(t,x,u,flag) 
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 6;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 7;
sizes.NumInputs      = 10;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [0,0,0,0,0,0];
str = [];
ts  = [0 0];
function sys=mdlDerivatives(t,x,u)
g=9.8;
if t>=0&&t<10
    m=3;
else if  t>=10&&t<20
        m=2;
    else if t>=20&&t<=30
        m=1;
    end
end
end
U1=u(1);
phi=u(5);
theta=u(6);
psi=u(7);
dx=0.1*sin(0.1*pi*t);
dy=0.1*cos(0.1*pi*t);
dz=0.1*sin(0.2*pi*t);

R13=cos(phi)*sin(theta)*cos(psi)+sin(phi)*sin(psi);
R23=cos(phi)*sin(theta)*sin(psi)-sin(phi)*cos(psi);
R33=cos(phi)*cos(theta);
sys(1)=x(2);
sys(2)=U1/m*R13+dx/m;    %ddx
sys(3)=x(4);
sys(4)=U1/m*R23+dy/m;    %ddy
sys(5)=x(6);
sys(6)=U1/m*R33-g+dz/m;  %ddz
function sys=mdlOutputs(t,x,u)
if t>=0&&t<10
    m=3;
else if  t>=10&&t<20
        m=2;
    else if t>=20&&t<=30
        m=1;
    end
end
end

sys(1)=x(1);
sys(2)=x(3);  
sys(3)=x(5);
sys(4)=x(2);  
sys(5)=x(4);  
sys(6)=x(6);
sys(7)=m;