function [sys,x0,str,ts]=s_function(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {1, 2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 6;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[0 0];
function sys=mdlOutputs(t,x,u)
g=9.8;epc=0.50;

x1=u(1);x2=u(2);
y1=u(3);y2=u(4);
th=u(5);dth=u(6);

z1=x1-epc*sin(th);
z2=x2-epc*cos(th)*dth;
dz1=z2;

z1d=t;dz1d=1;ddz1d=0;
z1e=z1-z1d;
dz1e=dz1-dz1d;

w1=y1+epc*(cos(th)-1);
w2=y2-epc*sin(th)*dth;
dw1=w2;

w1d=sin(t);dw1d=cos(t);ddw1d=-sin(t);
w1e=w1-w1d;
dw1e=dw1-dw1d;

%alfa1 and beta1 must meet alfa11+beta1<=sqrt(3)/2(-alfa2-beta2-1+g)
%alfa2 and beta2 must meet alfa12+beta2+1<g
alfa1=1.0;beta1=1.0;k1=10;l1=10;
alfa2=3.0;beta2=3.0;k2=10;l2=10;

v1=-alfa1*tanh(k1*z1e+l1*dz1e)-beta1*tanh(l1*dz1e)+ddz1d;
v2=-alfa2*tanh(k2*w1e+l2*dw1e)-beta2*tanh(l2*dw1e)+ddw1d;   

u1b=sqrt(v1^2+(v2+g)^2);
u1=u1b+epc*dth^2;
thd=atan(-v1/(v2+g));

sys(1)=u1;
sys(2)=thd;