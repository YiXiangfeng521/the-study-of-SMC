close all;

figure(1);
subplot(211);
plot(t,y(:,1),'k',t,y(:,2),'k:','linewidth',2);
xlabel('time(s)');ylabel('Angle tracking');
legend('ideal angle','angle tracking');
subplot(212);
plot(t,cos(t),'k',t,y(:,3),'k:','linewidth',2);
xlabel('time(s)');ylabel('Angle speed tracking');
legend('ideal angle speed','angle speed tracking');

figure(2);
plot(t,wc(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('wc');

figure(3);
plot(t,tol(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('Control input');