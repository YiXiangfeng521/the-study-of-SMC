%Parameters Value
m=2;l=0.2;g=9.8;
K1=0.01;K2=0.01;K3=0.01;K4=0.012;K5=0.012;K6=0.012;
I1=1.25;I2=1.25;I3=2.5;

epc=1.0;k=5;k0=1;k1=5;   %for du1
kz1=1;kz2=0.1;kz3=1; %for u1d

c_phi=1;M_phi=5;k_phi=10;   %for u4

beta3=2;rho=1;   %for M
eta=0.10;  %for d1,d2
c1=27;c2=27;c3=9;eta1=3;   %for s and u2,u3