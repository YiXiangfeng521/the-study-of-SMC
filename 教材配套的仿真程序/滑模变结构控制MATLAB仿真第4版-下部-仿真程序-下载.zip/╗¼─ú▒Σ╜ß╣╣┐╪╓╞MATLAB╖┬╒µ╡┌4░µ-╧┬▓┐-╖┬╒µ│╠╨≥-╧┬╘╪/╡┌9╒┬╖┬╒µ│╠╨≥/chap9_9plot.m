close all;
epc=0.50;
z1d=t;th=p(:,5);
x1d=z1d+epc*sin(th);

w1d=sin(t);
y1d=w1d-epc*(cos(th)-1);

figure(1);
subplot(211);
plot(t,z1d,'k',t,p(:,1),'r:','linewidth',2);
xlabel('time(s)');ylabel('x1 tracking');
legend('ideal x1','practical x1');
subplot(212);
plot(t,w1d,'k',t,p(:,3),'r:','linewidth',2);
xlabel('time(s)');ylabel('y1 tracking');
legend('ideal y1','practical y1');

figure(2);
subplot(211);
plot(t,thd(:,1),'k',t,p(:,5),'r:','linewidth',2);
xlabel('time(s)');ylabel('th tracking');
legend('given thd','practical th');
subplot(212);
plot(t,dthd(:,1),'k',t,p(:,6),'r:','linewidth',2);
xlabel('time(s)');ylabel('w tracking');
legend('given dthd','practical dthd');

figure(3);
subplot(211);
plot(t,ut(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('control input u1');
subplot(212);
plot(t,ut(:,2),'k','linewidth',2);
xlabel('time(s)');ylabel('control input u2');

figure(4);
plot(z1d,w1d,'r','linewidth',2);
hold on;
plot(p(:,1),p(:,3),'-.k','linewidth',2);
xlabel('x');ylabel('y');
legend('ideal trajectory','practical trajectory');