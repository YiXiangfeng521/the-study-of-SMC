function [sys,x0,str,ts]=chap14_5ctrl2(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 15;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[-1 0];
function sys=mdlOutputs(t,x,u)
chap9_6int;                  %��������

%������΢�ַ��̻��ֵõ���λ�ú��ٶȡ��ǶȺͽ��ٶ���Ϣ
xx1=u(1);dx1=u(2);y=u(3);dy=u(4);z=u(5);dz=u(6);theta=u(7);dtheta=u(8);
psi=u(9);dpsi=u(10);phi=u(11);dphi=u(12);
zd=u(13);phid=u(14);
u1=u(15);

%Ƿ����ϵͳ�Ļ�ģ�������
T=u1*[cos(phi),sin(phi);sin(phi),-cos(phi)];

x1=T^-1*[xx1,y]';
x2=T^-1*[dx1,dy]';
x3=[theta,psi]';
x4=[dtheta,dpsi]';
b=eye(2);
f1=[sin(theta)*cos(psi);sin(psi)];

df1_dx3=[cos(theta)*cos(psi),-sin(theta)*sin(psi);0 cos(psi)];
e1=x1;
e2=x2;
e3=f1;
e4=df1_dx3*x4;

E1=[x1,x2]';

s=c1*e1+c2*e2+c3*e3+e4;
dt_df1_dx3=[-dtheta*sin(theta)*cos(psi)-dpsi*cos(theta)*sin(psi),-dtheta*cos(theta)*sin(psi)-dpsi*sin(theta)*cos(psi);
                                        0                               ,                   -dpsi*sin(psi)                      ];
d1U=k/(abs(g-eta));   
d2U=k/(abs(g-eta))+max(K1/m,K2/m);
d3U=max(l*K4/I1,l*K5/I2);

M=(c1*d1U+c2*d2U)*norm(E1)+beta3*d3U*norm(x4)+rho;

ut=-inv(df1_dx3*b)*(c1*x2+c2*f1+c3*df1_dx3*x4+dt_df1_dx3*x4+M*sat(s)+eta1*s);  %��ģ������

u2=ut(1);
u3=ut(2);

sys(1)=u2;
sys(2)=u3;