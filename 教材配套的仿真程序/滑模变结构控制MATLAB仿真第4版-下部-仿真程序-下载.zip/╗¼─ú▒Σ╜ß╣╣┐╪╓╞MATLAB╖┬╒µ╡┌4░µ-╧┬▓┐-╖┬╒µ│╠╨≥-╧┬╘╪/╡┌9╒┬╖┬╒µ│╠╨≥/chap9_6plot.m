close all;

figure(1);
subplot(311);
plot(t,y(:,1),'k','linewidth',2);
legend('x(m)');
subplot(312);
plot(t,y(:,3),'k','linewidth',2);
legend('y(m)');
subplot(313);
plot(t,3*t./t,'k',t,y(:,5),'k:','linewidth',2);
legend('zd(m)','z(m)');

figure(2);
subplot(311);
plot(t,y(:,7)/pi*180,'k','linewidth',2);
legend('\theta (degree)');
subplot(312);
plot(t,y(:,9)/pi*180,'k','linewidth',2);
legend('\psi (degree)');
subplot(313);
plot(t,60*t./t,'k',t,y(:,11)/pi*180,'k:','linewidth',2);
legend('\phid(degree)','\phi (degree)');

u1=ut(:,1);u4=ut(:,2);u2=ut(:,3);u3=ut(:,4);
figure(3);
plot(t,u1d,'k','linewidth',2);
hold on
plot(t,u1,'k:','linewidth',2);
legend('u1d','u1');

figure(4);
subplot(411);
plot(t,u1,'k','linewidth',2);
legend('u1');
subplot(412);
plot(t,u2,'k','linewidth',2);
legend('u2');
subplot(413);
plot(t,u3,'k','linewidth',2);
legend('u3');
subplot(414);
plot(t,u4,'k','linewidth',2);
legend('u4');