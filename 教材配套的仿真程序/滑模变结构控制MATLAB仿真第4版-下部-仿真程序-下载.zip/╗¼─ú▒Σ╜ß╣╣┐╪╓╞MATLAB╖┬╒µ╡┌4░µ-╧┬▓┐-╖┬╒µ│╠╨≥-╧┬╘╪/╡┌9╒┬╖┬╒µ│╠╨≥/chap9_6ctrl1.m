function [sys,x0,str,ts]=chap14_5ctrl1(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 3;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 3;
sizes.NumInputs      = 14;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[0 0 12.8];
str=[];
ts=[-1 0];

function sys=mdlDerivatives(t,x,u)
%������΢�ַ��̻��ֵõ���λ�ú��ٶȡ��ǶȺͽ��ٶ���Ϣ
xx1=u(1);dx1=u(2);y=u(3);dy=u(4);z=u(5);dz=u(6);theta=u(7);dtheta=u(8);
psi=u(9);dpsi=u(10);phi=u(11);dphi=u(12);
zd=u(13);phid=u(14);

chap9_6int;      %���ò����ļ�

int_u1=x(1);
int_z=x(2);
u1=x(3);

u1d=(kz1*(zd-z)+kz2*int_z-kz3*dz+g)/(cos(phi)*cos(psi));

du1=k*sat_du1((k0*int_u1+k1*(u1d-u1))/epc); 

sys(1)=u1d-u1;
sys(2)=zd-z;
sys(3)=du1;
function sys=mdlOutputs(t,x,u)
u1=x(3);
int_z=x(2);

%������΢�ַ��̻��ֵõ���λ�ú��ٶȡ��ǶȺͽ��ٶ���Ϣ
xx1=u(1);dx1=u(2);y=u(3);dy=u(4);z=u(5);dz=u(6);theta=u(7);dtheta=u(8);
psi=u(9);dpsi=u(10);phi=u(11);dphi=u(12);
zd=u(13);phid=u(14);

chap9_6int;
s_phi=c_phi*(phi-phid)+dphi;
u4=-c_phi*dphi-M_phi*sat(s_phi)-k_phi*s_phi;

u1d=(kz1*(zd-z)+kz2*int_z-kz3*dz+g)/(cos(phi)*cos(psi));
sys(1)=u1;
sys(2)=u1d;
sys(3)=u4;