function [sys,x0,str,ts]=s_function(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {1, 2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 6;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[ ];
str=[];
ts=[0 0];
function sys=mdlOutputs(t,x,u)
xd=0;dxd=0;ddxd=0; %ideal xd signal
yd=0.1*sin(t);dyd=0.1*cos(t);ddyd=-0.1*sin(t); %ideal yd signal
epc=0.50;

x1=u(1);x2=u(2);
y1=u(3);y2=u(4);
th=u(5);    %angle
omega=u(6); %angle rate

e1=x1-xd;e2=x2-dxd;
e3=y1-yd;e4=y2-dyd;

eta=epc*omega-e2*cos(th)-e4*sin(th);%coordinate transformation of estimation

%%%%%%%%%%%%%%%%%%%%%%;
g=9.8;
m1=epc/g;
m2=-epc*(3+m1);
m3=-3*epc/g-1;
M=[m1 m2 m3];
AM=[m1 m2 m3;(1/epc)*m1 (1/epc)*m2 (1/epc)+(1/epc)*m3;0 g 0];
%Stability Judgement
eig(AM);
%%%%%%%%%%%%%%%%%%%%%%%
M=[m1 m2 m3];
mu1=e2;
mu2=[e1 th eta]';

s=mu1-M*mu2;

p1=e2;
p2=(1/epc)*(eta+e2*cos(th)+e4*sin(th));
p3=(1/epc)*(eta+e2*cos(th)+e4*sin(th))*(e2*sin(th)-e4*cos(th))+ddxd*cos(th)+(ddyd+g)*sin(th);
p=[p1;p2;p3];

fai=0.01;
if abs(s)<=fai
   sat=s/fai;
else
   sat=sign(s);
end
h1=15;
%v1=M*p-h1*sign(s);
v1=M*p-h1*sat;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
c=50;
rou1=c*e3+e4;
fai=0.01;
if abs(rou1)<=fai
   sat1=rou1/fai;
else
   sat1=sign(rou1);
end

h2=10;
%v2=-c*e4-h2*sign(rou1);
v2=-c*e4-h2*sat1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T=[-sin(th) epc*cos(th);cos(th) epc*sin(th)];
ut=inv(T)*[v1+ddxd;v2+ddyd+g];

sys(1)=ut(1);
sys(2)=ut(2);