function [sys,x0,str,ts]=s_function(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {1, 2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 6;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[0 0];
function sys=mdlOutputs(t,x,u)
xd=sin(t);dxd=cos(t);ddxd=-sin(t);
yd=cos(t);dyd=-sin(t);ddyd=-cos(t);
g=9.8;

x1=u(1);x2=u(2);
y1=u(3);y2=u(4);
th=u(5);dth=u(6);

x1e=x1-xd;
x2e=x2-dxd;
y1e=y1-yd;
y2e=y2-dyd;

c1=10;c2=10;
xite1=3;xite2=3;
s1=c1*x1e+x2e;
s2=c2*y1e+y2e;

v1=-c1*x2e+ddxd-xite1*s1;
v2=g+ddyd-c2*y2e-xite2*s2;

u1=sqrt(v1^2+v2^2);
thd=atan(-v1/v2);

sys(1)=u1;
sys(2)=thd;