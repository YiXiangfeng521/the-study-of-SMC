close all;

figure(1);
subplot(211);
plot(t,y(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('x1 response');
subplot(212);
plot(t,y(:,2),'k','linewidth',2);
xlabel('time(s)');ylabel('x2 response');

figure(2);
subplot(211);
plot(t,ut(:,1),'r','linewidth',2);
xlabel('time(s)');ylabel('Control input at t');
subplot(212);
plot(t,ut(:,2),'r','linewidth',2);
xlabel('time(s)');ylabel('Control input with delay');