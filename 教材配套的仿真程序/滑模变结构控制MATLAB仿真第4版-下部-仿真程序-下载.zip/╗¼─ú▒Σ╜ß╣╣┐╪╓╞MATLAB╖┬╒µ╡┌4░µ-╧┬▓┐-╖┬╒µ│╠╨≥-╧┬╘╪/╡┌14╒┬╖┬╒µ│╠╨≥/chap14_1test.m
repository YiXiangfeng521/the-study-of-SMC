clear all;
close all;
a=2;b=2;

c=1.5;   %a>c
xite1=1;xite2=2;
kesi1=2;kesi2=1;kesi3=2;

tol=1.0;
w=3;
k=0.2;

tol_max=xite1/(w*k)

m1=xite1*a*c+xite1*b-xite1*c^2-xite2;
m2=xite1*(a-c);
m3=xite1*b;

C1=xite1-w*tol*k
C2=m2-abs(m1)/(2*kesi1)-abs(m2)/(2*kesi2)
C3=m3*c-kesi1*abs(m1)/2-abs(m3)/(2*kesi3)
C4=w/tol-kesi2*abs(m2)/2-kesi3*abs(m3)/2