close all;

figure(1);
subplot(211);
plot(t,x(:,1),'r',t,xp(:,1)','-.k','linewidth',2);
legend('th','thp');xlabel('time/(s)');ylabel('angle');
subplot(212);
plot(t,x(:,2),'r',t,xp(:,2)','-.k','linewidth',2);
legend('dth','dthp');xlabel('time/(s)');ylabel('angle speed');
figure(2);
plot(t,ut(:,1),'r','linewidth',2);
xlabel('time/(s)');ylabel('ut');