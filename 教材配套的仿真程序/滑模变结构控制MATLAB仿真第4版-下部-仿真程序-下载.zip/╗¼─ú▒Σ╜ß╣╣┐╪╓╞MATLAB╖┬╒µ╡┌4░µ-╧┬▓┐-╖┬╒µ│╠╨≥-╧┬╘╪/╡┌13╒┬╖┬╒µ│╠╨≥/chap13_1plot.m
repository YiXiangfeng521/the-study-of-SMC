close all;

figure(1);
subplot(211);
plot(t,sin(t),'k',t,q(:,1),'r:','linewidth',2);
xlabel('time(s)');ylabel('Angle tracking of master plant');
legend('ideal signal','master tracking');
subplot(212);
plot(t,q(:,1),'k',t,q(:,3),'r:','linewidth',2);
xlabel('time(s)');ylabel('Angle tracking of slave plant');
legend('master signal','slave tracking');

figure(2);
subplot(211);
plot(t,cos(t),'k',t,q(:,2),'r:','linewidth',2);
xlabel('time(s)');ylabel('Angle speed tracking of master plant');
legend('ideal speed signal','master speed tracking');
subplot(212);
plot(t,q(:,2),'k',t,q(:,4),'r:','linewidth',2);
xlabel('time(s)');ylabel('Angle speed tracking of slave plant');
legend('master speed signal','slave speed tracking');

figure(3);
subplot(211);
plot(t,ut(:,1),'r','linewidth',2);
xlabel('time(s)');ylabel('Control input of master,tolm');

subplot(212);
plot(t,ut(:,2),'r','linewidth',2);
xlabel('time(s)');ylabel('Control input of slave,tols');