function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {1,2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];
function sys=mdlOutputs(t,x,u)
qm=u(1);dqm=u(2);qs=u(3);dqs=u(4);
qd=sin(t);dqd=cos(t);ddqd=-sin(t);

em=qm-qd;es=qs-qm;
dem=dqm-dqd;
des=dqs-dqm;

nm=30;ns=30;
rm=dem+nm*em;
rs=des+ns*es;

epcM=0.51;epcS=1.1;

fai=0.10;
if abs(rm)<=fai
   sat_rm=rm/fai;
else
   sat_rm=sign(rm);
end
if abs(rs)<=fai
   sat_rs=rs/fai;
else
   sat_rs=sign(rs);
end

%vm=-epcM*sign(rm);
%vs=-epcS*sign(rs);

vm=-epcM*sat_rm;
vs=-epcS*sat_rs;

km=10;ks=10;
 tolm=-km*rm+vm+ddqd-nm*dem;
 tols=-ks*rs+tolm+vs-ns*des;
    
sys(1)=tolm;
sys(2)=tols;