function [sys,x0,str,ts]=sharper(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {1, 2, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end

function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 3;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[];
str=[];
ts=[0 0];
function sys=mdlOutputs(t,x,u)
m=4.4;b=18;k=2317;F=27.8;

r=u(1);
dr=0;ddr=0;
x1=u(2);
x2=u(3);

e=x1-r;
de=x2-dr;

c=50;
s=c*e+de;
xite1=15;
xite2=0.10;

delta=0.05;
kk=1/delta;
if abs(s)>delta
    sats=sign(s);
else
    sats=kk*s;
end

%ut=m/F*(-c*de+1/m*(b*x2+k*x1)+ddr-xite1*s-xite2*sign(s));
ut=m/F*(-c*de+1/m*(b*x2+k*x1)+ddr-xite1*s-xite2*sats);
sys=ut;