%Discrete controller for continuous plant
clear all;
close all;

ts=0.001;  %Sampling time
xk=zeros(2,1);
u_1=0;
for k=1:1:2000
time(k) =k*ts;

xd(k)=sin(2*pi*k*ts);
dxd(k)=2*pi*cos(2*pi*k*ts);
ddxd(k)=-(2*pi)^2*sin(2*pi*k*ts);

para=u_1;
tSpan=[0 ts];
[tt,xx]=ode45('chap12_2plant',tSpan,xk,[],para);
xk = xx(length(xx),:);
x1(k)=xk(1); 
x2(k)=xk(2); 

e(k)=x1(k)-xd(k);

fx(k)=-25*x2(k);
xite=10;

de(k)=x2(k)-dxd(k);

c=10;
s(k)=c*e(k)+de(k);
epc=10;
D=0.51;

delta1=0.05;
M=1/delta1;
if abs(s(k))>delta1
   sats=sign(s(k));
else
   sats=M*s(k);
end

v(k)=-fx(k)+ddxd(k)-xite*s(k)-c*de(k);
delta=0.10;

m1=0.50;
m1b=m1/(1-delta)+0.10;
w(k)=-(1+delta)*(v(k)*tanh(s(k)*v(k)/epc)+m1b*tanh(s(k)*m1b/epc)+D*sats+xite*s(k));

eu(k)=w(k)-u_1;
if abs(eu(k))>=delta*abs(u_1)+m1
    u(k)=w(k);
    u_1=w(k);
else
    u(k)=u_1;    
end

end
figure(1);
subplot(211);
plot(time,xd,'r',time,x1,'k:','linewidth',2);
xlabel('time(s)');ylabel('xd,x1');
legend('Ideal position signal','Position tracking');
subplot(212);
plot(time,dxd,'r',time,x2,'k:','linewidth',2);
xlabel('time(s)');ylabel('dxd,x2');
legend('Ideal speed signal','Speed tracking');

figure(2);
plot(time,u,'r','linewidth',2);
xlabel('time(s)');ylabel('Control input');