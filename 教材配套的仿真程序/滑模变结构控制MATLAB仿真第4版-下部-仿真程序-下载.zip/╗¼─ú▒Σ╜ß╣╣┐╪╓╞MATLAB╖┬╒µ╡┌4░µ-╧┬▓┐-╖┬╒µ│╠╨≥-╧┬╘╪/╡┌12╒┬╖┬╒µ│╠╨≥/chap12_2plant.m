function dx = PlantModel(t,x,flag,para)
dx=zeros(2,1);
u=para;
d=0.5*sin(pi*t);

dx(1)=x(2);
dx(2)=-25*x(2)+u+d;