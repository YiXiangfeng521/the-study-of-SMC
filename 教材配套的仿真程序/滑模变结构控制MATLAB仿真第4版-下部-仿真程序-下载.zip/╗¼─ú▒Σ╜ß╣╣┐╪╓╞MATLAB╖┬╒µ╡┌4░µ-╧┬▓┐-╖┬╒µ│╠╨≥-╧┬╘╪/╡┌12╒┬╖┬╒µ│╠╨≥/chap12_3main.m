%Discrete controller for continuous plant
clear all;
close all;

ts=0.001;  %Sampling time
xk=zeros(2,1);
u_1=0;
mup_1=0;

for k=1:1:20000
time(k) =k*ts;

xd(k)=sin(k*ts);
dxd(k)=cos(k*ts);
ddxd(k)=-sin(k*ts);

para=u_1;
tSpan=[0 ts];
[tt,xx]=ode45('chap12_3plant',tSpan,xk,[],para);
xk = xx(length(xx),:);
x1(k)=xk(1); 
x2(k)=xk(2); 

e(k)=x1(k)-xd(k);
de(k)=x2(k)-dxd(k);

c=10;
s(k)=c*e(k)+de(k);
epc=0.10;

m=0.15;mb=0.20;
gama=0.10;
xite=2.0;
u_bar(k)=-ddxd(k)+c*de(k)+xite*s(k);
rho=0.020;
sigma=0.20;

mup(k)=mup_1+(gama*s(k)*u_bar(k)-gama*sigma*mup_1)*ts;
w(k)=-mb*tanh(s(k)*mb/epc)-s(k)*mup(k)^2*u_bar(k)^2/(abs(s(k)*mup(k)*u_bar(k))+rho);

kk=0.5;
Qu(k)=kk*round(u_1/kk);
eu(k)=w(k)-Qu(k);
if abs(eu(k))>=m
    u(k)=w(k);
    u_1=w(k);
else
    u(k)=u_1;    
end

mup_1=mup(k);
u_1=u(k);
end
figure(1);
subplot(211);
plot(time,xd,'r',time,x1,'k:','linewidth',2);
xlabel('time(s)');ylabel('xd,x1');
legend('Ideal position signal','Position tracking');
subplot(212);
plot(time,dxd,'r',time,x2,'k:','linewidth',2);
xlabel('time(s)');ylabel('dxd,x2');
legend('Ideal speed signal','Speed tracking');

figure(2);
subplot(211);
plot(time,u,'r','linewidth',2);
xlabel('time(s)');ylabel('Control input,ut');
subplot(212);
plot(time,Qu,'r','linewidth',2);
xlabel('time(s)');ylabel('Control input,Qu');

figure(3);
plot(u,Qu,'r','linewidth',2);
xlabel('ut');ylabel('Qu');