%Discrete controller for continuous plant
clear all;
close all;

ts=0.001;  %Sampling time
xk=zeros(2,1);
u_1=0;
for k=1:1:2000
time(k) =k*ts;

xd(k)=sin(2*pi*k*ts);
dxd(k)=2*pi*cos(2*pi*k*ts);
ddxd(k)=-(2*pi)^2*sin(2*pi*k*ts);

para=u_1;
tSpan=[0 ts];
[tt,xx]=ode45('chap12_1plant',tSpan,xk,[],para);
xk = xx(length(xx),:);
x1(k)=xk(1); 
x2(k)=xk(2); 

e(k)=x1(k)-xd(k);

fx(k)=-25*x2(k);
gx(k)=133;
xite=10;

de(k)=x2(k)-dxd(k);

c=10;
s(k)=c*e(k)+de(k);
epc=10;
%m=0.5;mb=1.0;
%m=1.5;mb=2.0;
m=0.15;mb=0.20;
D=0.51;

delta=0.20;
M=1/delta;
if abs(s(k))>delta
   sats=sign(s(k));
else
   sats=M*s(k);
end
w(k)=1/gx(k)*(-fx(k)+ddxd(k)-c*de(k)-xite*s(k))-D*sats-mb*tanh(gx(k)*s(k)*mb/epc);

eu(k)=w(k)-u_1;
if abs(eu(k))>=m
    u(k)=w(k);
    u_1=w(k);
else
    u(k)=u_1;    
end

end
figure(1);
subplot(211);
plot(time,xd,'r',time,x1,'k:','linewidth',2);
xlabel('time(s)');ylabel('xd,x1');
legend('Ideal position signal','Position tracking');
subplot(212);
plot(time,dxd,'r',time,x2,'k:','linewidth',2);
xlabel('time(s)');ylabel('dxd,x2');
legend('Ideal speed signal','Speed tracking');

figure(2);
plot(time,u,'r','linewidth',2);
xlabel('time(s)');ylabel('Control input');