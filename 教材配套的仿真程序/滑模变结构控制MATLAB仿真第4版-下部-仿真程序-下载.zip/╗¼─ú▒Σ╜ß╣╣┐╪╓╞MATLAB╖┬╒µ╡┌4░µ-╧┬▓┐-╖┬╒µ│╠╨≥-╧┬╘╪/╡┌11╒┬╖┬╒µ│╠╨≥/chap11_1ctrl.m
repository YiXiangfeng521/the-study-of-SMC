function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 2;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 2;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  =[0.1 1.0];
str = [];
ts = [0 0];
function sys=mdlDerivatives(t,x,u)
x1=u(1);x2=u(2);

rou1=0.95;rou2=0.95;
x1F=rou1*x1;
x2F=rou2*x2;

c=20;
e1=x1F;e2=x2F;
s=c*e1+e2;

faip=x(1);

k1=4;k2=1;
D=1.0;
xite=D+0.10;

alfa=k1*s+faip*x2F+xite*sign(s);
vb=-k2*s+alfa;
gama1=1.0;gama2=1.0;
dfai=gama1*s*x2F;
dk=gama2*s*vb;
sys(1)=dfai; 
sys(2)=dk; 
function sys=mdlOutputs(t,x,u)
global bj cij

x1=u(1);x2=u(2);

rou1=0.95;rou2=0.95;
x1F=rou1*x1;x2F=rou2*x2;

c=20;
e1=x1F;e2=x2F;
s=c*e1+e2;

faip=x(1);

k1=4;k2=1;
D=1.0;
xite=D+0.10;

delta=0.05;
M=1/delta;

if abs(s)>delta
   sats=sign(s);
else
   sats=M*s;
end
alfa=k1*s+faip*x2F+xite*sats;
vb=-k2*s+alfa;

k=x(2);
Nk=k^2*cos(k);

vt=Nk*vb;

rou0=0.50;
ut=rou0*vt;
sys(1)=ut;