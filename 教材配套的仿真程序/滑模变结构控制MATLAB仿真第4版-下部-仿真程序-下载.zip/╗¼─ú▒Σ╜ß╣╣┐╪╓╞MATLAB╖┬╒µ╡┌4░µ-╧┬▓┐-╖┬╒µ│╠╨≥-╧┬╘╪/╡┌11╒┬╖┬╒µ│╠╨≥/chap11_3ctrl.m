function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
global bj cij
cij=[-2 -1 0 1 2;
    -2 -1 0 1 2;
    -2 -1 0 1 2;
    -2 -1 0 1 2];
bj=3.0;

sizes = simsizes;
sizes.NumContStates  = 6;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  =[0.1 0.1 0.1 0.1 0.1 1.0];
str = [];
ts = [0 0];
function sys=mdlDerivatives(t,x,u)
global bj cij
x1=u(1);x2=u(2);x3=u(3);x4=u(4);

rou1=0.95;rou2=0.95;rou3=0.95;rou4=0.95;
x1F=rou1*x1;
x2F=rou2*x2;
x3F=rou3*x3;
x4F=rou4*x4;

l=10;g=9.8;
c1=25;c2=2*g/l+10;c3=10;
s=c1*x1F+c2*x2F+c3*x3F+x4F;

W=[x(1) x(2) x(3) x(4) x(5)];
xi=[x1F x2F x3F x4F]';
 
h=zeros(5,1);
for j=1:1:5
    h(j)=exp(-norm(xi-cij(:,j))^2/(2*bj^2));
end
fn=W*h;

k1=4;k2=1;
D=3.0;
xite=D+0.10;

alfa=k1*s+fn+xite*sign(s);
vb=-k2*s+alfa;
gama1=1.0;gama2=1.0;
dk=gama2*s*vb;
for j=1:1:5
    sys(j)=gama1*s*h(j);
end
sys(6)=dk; 
function sys=mdlOutputs(t,x,u)
global bj cij

x1=u(1);x2=u(2);x3=u(3);x4=u(4);

rou1=0.95;rou2=0.95;rou3=0.95;rou4=0.95;
x1F=rou1*x1;
x2F=rou2*x2;
x3F=rou3*x3;
x4F=rou4*x4;

l=10;g=9.8;
c1=25;c2=2*g/l+10;c3=10;
s=c1*x1F+c2*x2F+c3*x3F+x4F;

W=[x(1) x(2) x(3) x(4) x(5)];
xi=[x1F x2F x3F x4F]';
 
h=zeros(5,1);
for j=1:1:5
    h(j)=exp(-norm(xi-cij(:,j))^2/(2*bj^2));
end
fn=W*h;

k1=4;k2=1;
D=3.0;
xite=D+0.10;

delta=0.05;
M=1/delta;

if abs(s)>delta
   sats=sign(s);
else
   sats=M*s;
end
alfa=k1*s+fn+xite*sats;
vb=-k2*s+alfa;

k=x(6);
Nk=k^2*cos(k);

vt=Nk*vb;

rou0=0.50;
ut=rou0*vt;
sys(1)=ut;