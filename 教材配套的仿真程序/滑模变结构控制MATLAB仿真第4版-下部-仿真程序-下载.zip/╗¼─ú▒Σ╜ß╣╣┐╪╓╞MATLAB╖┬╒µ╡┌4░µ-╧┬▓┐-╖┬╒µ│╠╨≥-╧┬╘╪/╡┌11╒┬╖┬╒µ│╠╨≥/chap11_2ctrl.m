function [sys,x0,str,ts] = spacemodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 1,
    sys=mdlDerivatives(t,x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
global bj cij
cij=[-2 -1 0 1 2];
bj=3.0;

sizes = simsizes;
sizes.NumContStates  = 6;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 2;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  =[0.1 0.1 0.1 0.1 0.1 1.0];
str = [];
ts = [0 0];
function sys=mdlDerivatives(t,x,u)
global bj cij
x1=u(1);x2=u(2);

rou1=0.95;rou2=0.95;
x1F=rou1*x1;
x2F=rou2*x2;

c=20;
e1=x1F;
e2=x2F;
s=c*e1+e2;

W=[x(1) x(2) x(3) x(4) x(5)];
xi=x2F;
 
h=zeros(5,1);
for j=1:1:5
    h(j)=exp(-norm(xi-cij(:,j))^2/(2*bj^2));
end
fn=W*h;

k1=4;k2=1;
D=1.0;
xite=D+0.10;

alfa=k1*s+fn+xite*sign(s);
vb=-k2*s+alfa;
gama1=1.0;gama2=1.0;
dk=gama2*s*vb;
for j=1:1:5
    sys(j)=gama1*s*h(j);
end
sys(6)=dk; 
function sys=mdlOutputs(t,x,u)
global bj cij

x1=u(1);x2=u(2);

rou1=0.95;rou2=0.95;
x1F=rou1*x1;x2F=rou2*x2;

c=20;
e1=x1F;
e2=x2F;
s=c*e1+e2;

W=[x(1) x(2) x(3) x(4) x(5)];
xi=x2F;
 
h=zeros(5,1);
for j=1:1:5
    h(j)=exp(-norm(xi-cij(:,j))^2/(2*bj^2));
end
fn=W*h;

k1=4;k2=1;
D=1.0;
xite=D+0.10;

delta=0.05;
M=1/delta;

if abs(s)>delta
   sats=sign(s);
else
   sats=M*s;
end
alfa=k1*s+fn+xite*sats;
vb=-k2*s+alfa;

k=x(6);
Nk=k^2*cos(k);

vt=Nk*vb;

rou0=0.50;
ut=rou0*vt;
sys(1)=ut;