close all;

figure(1);
plot(t,x(:,1),'k',t,x(:,2),'r:','linewidth',2);
xlabel('time(s)');ylabel('x1 and x2');
legend('x1','x2');

figure(2);
plot(t,ut(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('Control input');