close all;

figure(1);
subplot(211);
plot(t,y(:,1),'r',t,y(:,2),'b:','linewidth',2);
xlabel('time(s)');ylabel('angle tracking');
legend('ideal angle','angle tracking');
subplot(212);
plot(t,cos(t),'r',t,y(:,3),'b:','linewidth',2);
xlabel('time(s)');ylabel('speed tracking');
legend('ideal speed','speed tracking');

figure(2);
subplot(211);
plot(t,v(:,1),'k',t,u(:,1),'k:','linewidth',2);
xlabel('time(s)');ylabel('Control input,v and u');
legend('ideal control input,v','practical control input,u');
subplot(212);
plot(t,deltau(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('Control input compensation');
legend('delta u');