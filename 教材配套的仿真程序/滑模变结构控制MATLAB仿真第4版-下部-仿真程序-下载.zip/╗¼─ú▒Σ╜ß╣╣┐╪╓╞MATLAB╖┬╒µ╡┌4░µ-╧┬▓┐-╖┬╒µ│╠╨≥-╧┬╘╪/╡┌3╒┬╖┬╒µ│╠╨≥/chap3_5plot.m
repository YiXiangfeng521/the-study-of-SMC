close all;

figure(1);
plot(t,x(:,1),'k',t,x(:,2),'r:','linewidth',2);
xlabel('time(s)');ylabel('x1 and x2');
legend('x1','x2');

figure(2);
plot(t,ut(:,1),'k','linewidth',2);
xlabel('time(s)');ylabel('Control input');

figure(3);
plot(t,x(:,3),'r',t,ut(:,2),'-.b','linewidth',2);
xlabel('time(s)');ylabel('fx and its estimation');
legend('fx','fxp');