pa.k = 10;
pa.m = 1;
pa.k1 = 1;
pa.k2 = 1
