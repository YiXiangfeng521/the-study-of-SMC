function [sys,x0,str,ts,simStateCompliance] = Adaptive_ctrl(t,x,u,flag,pa)

switch flag,


  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;


  case 1,
    sys=mdlDerivatives(t,x,u,pa);


  case 2,
    sys=mdlUpdate(t,x,u);

  case 3,
    sys=mdlOutputs(t,x,u);


  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);


  case 9,
    sys=mdlTerminate(t,x,u);


  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));

end


function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes


sizes = simsizes;

sizes.NumContStates  = 1;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;   % at least one sample time is needed

sys = simsizes(sizes);

%
% initialize the initial conditions
%
x0  = 0;%hat_k的初始值为0

%
% str is always an empty matrix
%
str = [];

%
% initialize the array of sample times
%
ts  = [0 0];


simStateCompliance = 'UnknownSimState';


function sys=mdlDerivatives(t,x,u,pa)

x1d = u(1);
dot_x1d = u(2);
x2 = u(3);
x1 = u(4);

m = pa.m;
k1 = pa.k1;
e1 = x1d-x1;
e2 = dot_x1d+k1*e1-x2;

dot_hat_k = 1/m*e2*x1^3;
sys = dot_hat_k;


function sys=mdlOutputs(t,x,u)

hat_k = x;
sys = hat_k;


function sys=mdlTerminate(t,x,u)

sys = [];

% end mdlTerminate
function sys=mdlGetTimeOfNextVarHit(t,x,u)

sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

function sys=mdlUpdate(t,x,u)

sys = [];